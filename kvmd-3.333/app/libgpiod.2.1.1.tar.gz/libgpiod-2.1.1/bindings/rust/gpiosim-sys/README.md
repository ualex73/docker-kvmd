<!--
SPDX-License-Identifier: CC0-1.0
SPDX-FileCopyrightText: 2022 Linaro Ltd.
SPDX-FileCopyrightText: 2022 Viresh Kumar <viresh.kumar@linaro.org>
-->

# Generated gpiosim Rust FFI bindings
Automatically generated Rust FFI bindings via
	[bindgen](https://github.com/rust-lang/rust-bindgen).

## License

This project is licensed under either of

- [Apache License](http://www.apache.org/licenses/LICENSE-2.0), Version 2.0
- [BSD-3-Clause License](https://opensource.org/licenses/BSD-3-Clause)
